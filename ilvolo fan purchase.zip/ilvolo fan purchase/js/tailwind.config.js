module.exports = {
    theme: {
      extend: {
        colors: {
          'body': '#2c2d2a',
          'savanna-bg': '#e9bf8b',
          'beach-bg': '#e7dfcf',
          'glacier-bg': '#b6d6c8',
          'coral-bg': '#e86357',
          'arrow-fill': '#333231',
        },
        fontFamily: {
          'body': ['Montserrat', 'sans-serif'],
          'italic': ['EB Garamond', 'serif'],
        },
      },
    },
    plugins: [],
  };
  