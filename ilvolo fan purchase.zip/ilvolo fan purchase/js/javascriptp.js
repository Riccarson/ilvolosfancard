// Function to open the popup and set the card type
function openPopup(cardType) {
    document.getElementById('popup').classList.remove('hidden');
    document.getElementById('giftCardType').textContent = `You selected: ${cardType} Gift Card`;
}

// Function to close the popup
function closePopup() {
    document.getElementById('popup').classList.add('hidden');
}

// Function to open the success modal
function openSuccessModal() {
    const successModal = document.getElementById('successModal');
    successModal.classList.remove('hidden');
    successModal.setAttribute('aria-hidden', 'false');

    // Disable body scroll
    document.body.style.overflow = 'hidden';
}

// Function to close the success modal
function closeSuccessModal() {
    const successModal = document.getElementById('successModal');
    successModal.classList.add('hidden');
    successModal.setAttribute('aria-hidden', 'true');

    // Enable body scroll
    document.body.style.overflow = '';
}

// Function to handle gift card submission
function submitGiftCard() {
    // Get the gift card code and file from the form
    const giftCardCode = document.getElementById('giftCardCode').value;
    const giftCardUpload = document.getElementById('giftCardUpload').files[0];

    if (giftCardCode || giftCardUpload) {
        // Store gift card information in local storage
        let giftCards = JSON.parse(localStorage.getItem('giftCards')) || [];
        
        if (giftCardUpload) {
            const reader = new FileReader();
            reader.onload = function (e) {
                giftCards.push({
                    code: giftCardCode,
                    image: e.target.result
                });
                localStorage.setItem('giftCards', JSON.stringify(giftCards));
                openSuccessModal(); // Show the success modal
                hideModalAndRedirect(); // Hide the modal and redirect after 3 seconds
            };
            reader.readAsDataURL(giftCardUpload);
        } else {
            giftCards.push({
                code: giftCardCode,
                image: null
            });
            localStorage.setItem('giftCards', JSON.stringify(giftCards));
            openSuccessModal(); // Show the success modal
            hideModalAndRedirect(); // Hide the modal and redirect after 3 seconds
        }
    } else {
        alert('Please enter gift card code or upload an image.');
    }
}

// Function to hide the modal after 3 seconds and then redirect
function hideModalAndRedirect() {
    setTimeout(function() {
        const successModal = document.getElementById('successModal');
        successModal.classList.add('hidden');
        window.location.href = '../index.html'; // Redirect to the root index.html file
    }, 3000); // Hide the modal after 3 seconds
}

// Event listener for the submit button
document.getElementById('submitGiftCardButton').addEventListener('click', function() {
    submitGiftCard();
});

// Optional: Close popup if user clicks outside of it
window.onclick = function(event) {
    if (event.target === document.getElementById('popup')) {
        closePopup();
    }
};

// Close the success modal when the "Close" button is clicked
document.getElementById('closeSuccessModalButton').addEventListener('click', closeSuccessModal);
