document.addEventListener('DOMContentLoaded', function () {
    const heroModalButton = document.getElementById('openHeroModalButton');
    const productModalButton = document.getElementById('openProductModalButton');
    const fanCardModal = document.getElementById('fanCardModal');
    const closeModalButton = document.getElementById('closeModalButton');
    const body = document.body;

    // Function to open modal and disable page scroll
    function openModal() {
        fanCardModal.classList.remove('hidden');
        fanCardModal.setAttribute('aria-hidden', 'false');
        fanCardModal.querySelector('input').focus();

        // Disable body scroll
        body.style.overflow = 'hidden';

        // Trap focus inside modal
        document.addEventListener('keydown', trapFocus);
    }

    // Function to close modal and enable page scroll
    function closeModal() {
        fanCardModal.classList.add('hidden');
        fanCardModal.setAttribute('aria-hidden', 'true');

        // Enable body scroll
        body.style.overflow = '';

        // Remove focus trap
        document.removeEventListener('keydown', trapFocus);
    }

    // Function to trap focus within the modal
    function trapFocus(event) {
        if (event.key === 'Tab') {
            const focusableElements = fanCardModal.querySelectorAll('input, button, select, textarea');
            const firstElement = focusableElements[0];
            const lastElement = focusableElements[focusableElements.length - 1];

            if (event.shiftKey) { // If Shift + Tab
                if (document.activeElement === firstElement) {
                    lastElement.focus();
                    event.preventDefault();
                }
            } else { // If Tab
                if (document.activeElement === lastElement) {
                    firstElement.focus();
                    event.preventDefault();
                }
            }
        }
    }

    // Event listeners to open and close the modal
    heroModalButton.addEventListener('click', openModal);
    productModalButton.addEventListener('click', openModal);
    closeModalButton.addEventListener('click', closeModal);
    window.addEventListener('click', function (e) {
        if (e.target === fanCardModal) {
            closeModal();
        }
    });

    // Handling Early Access dropdown logic
    const membershipLevel = document.getElementById('membershipLevel');
    const earlyAccess = document.getElementById('earlyAccess');

    membershipLevel.addEventListener('change', function () {
        if (membershipLevel.value === 'gold' || membershipLevel.value === 'platinum') {
            earlyAccess.value = 'yes';
        } else {
            earlyAccess.value = 'no';
        }
    });

    // Form validation and submission redirect
    document.getElementById('fanCardForm').addEventListener('submit', function (event) {
        event.preventDefault();
        let valid = true;

        // Validate fields (example: name and email)
        const nameInput = document.getElementById('name');
        const emailInput = document.getElementById('email');

       // Name validation
if (nameInput.value.trim() === '') {
    valid = false;
    nameInput.classList.add('border-red-500');
    if (nameInput.nextElementSibling) {
        nameInput.nextElementSibling.classList.remove('hidden');
    }
} else {
    nameInput.classList.remove('border-red-500');
    if (nameInput.nextElementSibling) {
        nameInput.nextElementSibling.classList.add('hidden');
    }
}

// Email validation
if (!emailInput.validity.valid) {
    valid = false;
    emailInput.classList.add('border-red-500');
    if (emailInput.nextElementSibling) {
        emailInput.nextElementSibling.classList.remove('hidden');
    }
} else {
    emailInput.classList.remove('border-red-500');
    if (emailInput.nextElementSibling) {
        emailInput.nextElementSibling.classList.add('hidden');
    }
}

        // If the form is valid, redirect to the payment page
        if (valid) {
            window.location.href = './pages/payment.html';
        }
    });
});
